Warm reminder: Updating BIOS carries risks, please proceed with caution. During the BIOS update process, do not interrupt the update or turn off the power, as this may cause the motherboard to not boot up.

BIOS update steps:

1. Format a regular USB drive to FAT32 format. Do not use PE or DOC boot disks or any other types of boot disks.

2. Download the BIOS compressed package from the official website and extract the contents. Copy the extracted EFI folder to the root directory of the USB drive you will use for flashing the BIOS.

3. Plug the USB drive into the USB port of the motherboard you want to flash the BIOS on. Turn on the computer and press the 'Delete' key on the keyboard to enter the motherboard BIOS interface.

4. In the BIOS interface under the Startup module, set the "Flash/BIOS Write Protect" feature to [Disabled]. Press F10 to confirm, save, and restart.

5. After restarting, continuously press the "F11" key on the keyboard to enter the motherboard's shortcut boot interface. Select the UEFI boot option for the USB drive.

6. At this point, you will enter the UEFI boot shell interface. The program for flashing the motherboard BIOS will automatically execute in this interface. Do not interrupt the flashing process, or it may cause the motherboard to not boot up.

7. The BIOS flashing process may take from several seconds to a few minutes. Please be patient and wait.

8. When the motherboard displays yellow text "FS0:\EFI\BOOT>" and the BIOS update stops, or green text appears indicating the update is complete, the motherboard BIOS update is finished.

9. After updating the BIOS, it is recommended to disconnect the AC power supply, clear the CMOS information of the motherboard, then power on the system and enter the BIOS. Press F9 to load optimized defaults and F10 to save and restart for normal use.